"""Prioritize affected and previously unexecuted groups, then finish same identity."""
import subprocess
import sys
import grouped_regression as runner

def main():
    groups = runner.group_ids([test.id() for test in runner.discover()])
    anchor = 'test_formal_valuation_batch_guards.ValuationBatchGuardTests'
    index = next(i for i, group in enumerate(groups)
                 if all(t.rsplit('.', 1)[0] == anchor for t in group))
    if len(groups) != 171 or index != 152:
        raise RuntimeError('Group inventory changed; refusing assumed preflight scope')
    for group in groups[index:]:
        selector = group[0] if len(group) == 1 else group[0].rsplit('.', 1)[0]
        print('PREFLIGHT_GROUP ' + selector, flush=True)
        result = subprocess.run([sys.executable, '-u', '-X', 'faulthandler',
                                 runner.__file__, '--group', selector])
        if result.returncode:
            return result.returncode
    print('PREFLIGHT_PASSED; continuing full inventory under same identity', flush=True)
    return subprocess.run([sys.executable, '-u', '-X', 'faulthandler',
                           runner.__file__, '--all']).returncode

if __name__ == '__main__':
    raise SystemExit(main())
