# Next implementation checkpoint after 7105dd2 acceptance

Status: preparation only; no source changes and no new acceptance claim.
Prerequisite: exact attempt d6ed49c2aebc4bed94e6c11c3aafeb9c finishes successfully. Preserve current source/HEAD/helpers until then.

## Findings from plan/spec and current source
- Public validate(run_id) returns an unsigned audit DTO after the held context exits. It cannot authorize a later database write or rename.
- hold_evidence exposes detached diagnostics, not an owned publication capability. Exit-time source checks alone cannot prevent an earlier unauthorized side effect.
- Task 2 remains partial; Task 3 must bind fixed signer/verifier and private writer authority. No release repository implementation exists yet.
- Preparation must commit durably before rename. A subsequent IMMEDIATE transaction must recheck sources, exact candidate, lease and fencing generation before no-overwrite rename; retain source guard through completion.

## Ordered implementation slice
1. After acceptance, define private owner-held publication scope in the trusted service (no caller proof, callback, signer, verifier or skip override). Keep public audit result detached and audit-only.
2. RED boundary tests: forged/copied/expired/cross-service/cross-run evidence rejected; replaced methods/configuration rejected; source, job or registry mutation BEFORE a side effect blocks that side effect. Include exception cleanup and scope re-entry rejection.
3. Implement pre-side-effect validation using existing genuine producer/source guards. Do not infer current validity from a cached passing audit.
4. Couple signed audit persistence to the configured repository boundary; enforce purpose and fixed key identity. Distinguish failed validation diagnostics from successful publication authorization. Never synthesize missing candidate identity on a failed lookup.
5. Add durable preparation and lease/fencing transitions under Task 3, followed by filesystem publication under Task 4. Verify V8 invariance and own-V9-row writes do not invalidate exact source commitments.

## Verification constraints
- Existing 125 focused passes are scoped evidence, not full 2101-test acceptance.
- Current 20-member acceptance exercises the unsigned audit success path only; it does not prove publication authority or signing.
- New code needs fresh test identity; historical passing long tests must not be relabelled as current results.
- Do not launch duplicate long queues or modify the currently tested revision.
