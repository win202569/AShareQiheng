# V9 Task 2 integration readiness — abf3ba7
Scope: read-only preparation during retained-replay acceptance. Not gate results or publication authority.

| Gate | Existing evidence path | Integration still required |
|---|---|---|
| candidate_identity | _ReleaseInputRefresh.refresh -> real get_run; _check_candidate_binding | Bind diagnostic to configured run and private validation record |
| official_registry | refresh reloads ten-role official bundle and scoring/policy/valuation | Retain exact trusted configuration and recheck at each publication boundary |
| workspace_identity | fresh coverage revision compared with configured code | Recheck current workspace at use, never reuse old candidate code |
| frozen_universe | real frozen input + exact sorted SH/SZ/BJ membership | Attach authenticated frozen/universe commitments to validation |
| official_coverage | fresh auditor + require_official_ready | Keep fresh witness separate from original candidate coverage |
| source_identity_temporal | _hold_official_candidate retains source proofs/checkpoint | Internal commitment and pre-side-effect recheck; exit check alone cannot authorize publish |
| replay_equivalence | four genuine producers + exact canonical byte comparison | Nonempty differences must produce candidate_changed diagnostic, no capability |
| classification_complete | exact member/status membership; only formal_scored/pool_vetoed | Preserve strict pending/out-of-scope exclusion; no forced pool fill |
| score_formula | genuine D2 production with authenticated inputs | Associate gate with retained producer proof; no duplicate formula |
| pool_selection | genuine eligibility and pool producers | Preserve 20/50, industry4/10 and exact producer ordering |
| job_quiescence | formal task/source-circuit data exists | Dedicated fresh read for active leases, unexplained failures, blocking circuits; coverage success alone is insufficient |
| artifact_renderability | canonical value primitives exist | Concrete deterministic rendering validation still missing; cannot mark true merely because replay succeeds |

Sequence after current acceptance:
1. Inspect exact attempt result, including entered-body flag on source-change rejection.
2. Add configured validator ownership and run_id-only interface with negative tests; reuse _ReleaseInputRefresh, do not create another reader.
3. Integrate private retained context and source commitment; no externally supplied callback/guard/proof.
4. Implement missing job-quiescence/renderability checks and full gate diagnostics. Coordinate actual renderer dependency with Task4; do not fabricate a passing gate.
5. Mint live capability only after all gates succeed, with revalidation before preparation/rename. DTO/signature/recovered snapshots alone never authorize writes.
6. Repository lifecycle and publisher remain separate later tasks; unchanged V8 history must be asserted.

Ruling: preserve source/HEAD while the current official acceptance runs. Prepare this checklist outside the tested tree; source changes would invalidate its workspace identity. No task marked complete by this note.
