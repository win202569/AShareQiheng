# Next validator integration — prerequisite map at 8bb501c

This is a read-only implementation brief, not completed functionality. Do not edit tested source/HEAD while attempt c5962eedd3524288aa6a2e776d210e46 is active.

Confirmed interface gap:
- _ReleaseInputRefresh.hold_replay(run_id) yields only detached four-artifact bytes and job evidence bytes.
- ReleaseValidationPayload additionally requires the fresh coverage hash and full source_dependency_hash.
- Job evidence hash cannot stand in for the full source dependency commitment. Original candidate coverage cannot stand in for fresh validation coverage.
- Exit-time recheck cannot substitute for a check immediately before preparation/rename. Returning a diagnostic DTO cannot keep live authority valid after the guard exits.

Next implementation sequence after genuine rendering acceptance:
1. Retain fresh coverage and producer source commitment in an internal owned validation record inside the existing held context. No caller-supplied proof, hash, callback or guard. Reuse existing history/registry refresh; do not build another reader.
2. Bind the rendering function and its dependencies to the same captured-method/code checks used by the configured input service. Generate the package while the source guard remains active. Caller-provided identity metadata must be replaced by exact fields from the internally read candidate.
3. Assemble the fixed12-gate diagnostic payload using genuine evidence. All gates need explicit supporting evidence; do not mark all true merely because rendering succeeded. Keep original V8 hashes and fresh validation coverage separate.
4. Define private lifetime checks for publisher use: exact owner/run/root/source commitments, still-active context, not copied/reconstructed, rechecked before each irreversible boundary. Public inspection data and signatures alone grant no write authority.
5. Bind signing/configuration and append-only repository writes in the later repository task; do not expose mark-published or caller-selected verifier controls.

Required tests:
- Missing/test/blocked/old-code/wrong-root run rejected via real reader.
- Active task/circuit, changed history or replay difference => no publish capability.
- Fresh coverage commitment is used; original coverage remains unchanged.
- Job bytes alone cannot supply source_dependency_hash.
- Changed renderer/encoder or substituted output cannot pass artifact_renderability.
- Leaving a hold invalidates private publication use; source changes before preparation/rename rejected.
- All12 gates complete/unique with explicit evidence; public DTO/signed replay alone rejected by writer.
- V8 rows unchanged; zero pools allowed only with successful upstream gates.

No new approval is needed for these already-authorized code/test steps. No automatic formal publication follows successful tests.
